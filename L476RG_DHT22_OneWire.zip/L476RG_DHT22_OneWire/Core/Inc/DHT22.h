#ifndef DHT_H_
#define DHT_H_

//  Includes

#include "stm32l4xx_hal.h"


typedef struct
{
	float Temperature;
	float Humidity;
}DHT_DataTypedef;


void DHT_GetData (DHT_DataTypedef *DHT_Data);

//------Les Prototypes

//void delay(uint16_t delay_micro);
void Set_Pin_Output (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void Set_Pin_Input (GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void DHT_Start (void);
uint8_t DHT_Check_Response (void);
uint8_t DHT_Read (void);
void DHT_GetData (DHT_DataTypedef *DHT_Data);

#endif /* INC_DHT_H_ */
